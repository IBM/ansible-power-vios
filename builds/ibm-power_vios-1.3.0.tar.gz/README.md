<!-- This should be the location of the title of the repository, normally the short name -->
# IBM Power Systems VIOS Collection

The **IBM Power Systems VIOS collection** provides modules that can be used to manage configurations and
deployments of Power VIOS systems. The collection content helps to include workloads on
Power platforms as part of an enterprise automation strategy through the Ansible ecosystem.

## Join the Power Research Program

Become an IBM Power Design Partner. Engage with our Power Research team across various research studies to shape the future of Anisble on Power:
https://ibm.biz/BdyRyk

# Ansible Content for IBM Power Systems - VIOS

IBM Power Systems is a family of enterprise servers that helps transform your organization by delivering industry leading resilience, scalability and accelerated performance for the most sensitive, mission critical workloads and next-generation AI and edge solutions. The Power platform also leverages open source technologies that enable you to run these workloads in a hybrid cloud environment with consistent tools, processes and skills.

IBM Power Systems VIOS collection, as part of the broader offering of **Ansible Content for IBM Power Systems**, is available from Ansible Galaxy and has community support.

## Resources

For **guides** and **reference**, please visit the [Documentation](https://ibm.github.io/ansible-power-vios/) site.

## License

[GNU General Public License, Version 3.0](https://opensource.org/licenses/GPL-3.0).

## Copyright

© Copyright IBM Corporation 2020

