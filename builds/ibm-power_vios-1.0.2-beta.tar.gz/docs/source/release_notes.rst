.. ...........................................................................
.. © Copyright IBM Corporation 2020                                          .
.. ...........................................................................

Releases
========

Version 1.0.2-beta
------------------
Notes
  * Initial beta release of IBM Power Systems VIOS collection, referred to as power_vios

Availability
  * `Galaxy v1.0.2-beta`_
  * `GitHub v1.0.2-beta`_

.. _Galaxy v1.0.2-beta:
   https://galaxy.ansible.com/download/ibm-power_vios-1.0.2-beta.tar.gz

.. _GitHub v1.0.2-beta:
   https://github.com/IBM/ansible-power-vios/releases/download/v1.0.2/ibm-power_vios-1.0.2-beta.tar.gz

